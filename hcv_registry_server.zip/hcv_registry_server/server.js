const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8080;
const DATA_DIR = path.join(__dirname, 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj, null, 2);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 2_000_000) {
        reject(new Error('Payload troppo grande'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function safeHcvId(id) {
  const cleaned = String(id || '').trim().toUpperCase();
  if (!/^HCV-[A-Z0-9_-]{4,64}$/.test(cleaned)) return null;
  return cleaned;
}

function certPath(hcvId) {
  return path.join(DATA_DIR, `${hcvId}.json`);
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    return sendJson(res, 200, { ok: true });
  }

  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === 'GET' && url.pathname === '/health') {
      return sendJson(res, 200, { ok: true, service: 'hcv-registry' });
    }

    if (req.method === 'POST' && url.pathname === '/api/certificate') {
      const body = await readBody(req);
      const payload = JSON.parse(body || '{}');

      const hcvId = safeHcvId(payload.hcvId);
      const certificate = payload.certificate;

      if (!hcvId || !certificate || typeof certificate !== 'object') {
        return sendJson(res, 400, {
          ok: false,
          error: 'Richiesta non valida. Servono hcvId e certificate.',
        });
      }

      const metaId = certificate?.meta?.hcvId;
      if (metaId && safeHcvId(metaId) !== hcvId) {
        return sendJson(res, 400, {
          ok: false,
          error: 'hcvId non coincide con certificate.meta.hcvId',
        });
      }

      const record = {
        hcvId,
        createdAt: new Date().toISOString(),
        certificate,
      };

      fs.writeFileSync(certPath(hcvId), JSON.stringify(record, null, 2));

      return sendJson(res, 201, {
        ok: true,
        hcvId,
        url: `/api/certificate/${hcvId}`,
      });
    }

    const match = url.pathname.match(/^\/api\/certificate\/(HCV-[A-Za-z0-9_-]+)$/);
    if (req.method === 'GET' && match) {
      const hcvId = safeHcvId(match[1]);
      if (!hcvId) {
        return sendJson(res, 400, { ok: false, error: 'HCV-ID non valido' });
      }

      const file = certPath(hcvId);
      if (!fs.existsSync(file)) {
        return sendJson(res, 404, { ok: false, error: 'Certificato non trovato' });
      }

      const record = JSON.parse(fs.readFileSync(file, 'utf8'));
      return sendJson(res, 200, record);
    }

    return sendJson(res, 404, { ok: false, error: 'Endpoint non trovato' });
  } catch (err) {
    return sendJson(res, 500, { ok: false, error: String(err.message || err) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`HCV Registry listening on http://0.0.0.0:${PORT}`);
});
